<?php
session_start();
include('dbcon.php');
// echo "in login db";
if (isset($_POST['login_submit'])) {
    $emp_id = $_POST['employee_id'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM [Workbook].[dbo].[user] WHERE employee_id='$emp_id' AND password='$password'";
    $run = sqlsrv_query($con, $sql);
    // Display any SQL Server errors for debugging
    if ($run === false) {
        die(print_r(sqlsrv_errors(), true));
    }
    $row = sqlsrv_fetch_array($run, SQLSRV_FETCH_ASSOC);
    // for count
    $params = array();
    $options = array("Scrollable" => SQLSRV_CURSOR_KEYSET);
    $result = sqlsrv_query($con, $sql, $params, $options);
    $count = sqlsrv_num_rows($result);
    if ($count > 0) {
        $_SESSION['crmid'] = $row['employee_id'];
        $_SESSION['name'] = $row['user_name'];
        $_SESSION['dpmt'] = $row['department'];
        $_SESSION['admin'] = $row['dep_sup'];
        $_SESSION['sname'] = $row['sortname'];
        ?>
        <script>
            window.open('../dashboard.php', '_self');
        </script>
        <?php
    } else {
        ?>
        <script>
            alert('Employee_Id and Password Not Match... Try Again!');
            window.open('index.php', '_self');
        </script>
        <?php
    }
}
?>