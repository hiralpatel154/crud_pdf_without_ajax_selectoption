<?php include('session.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo $title ?>
    </title>
    <!-- Stylesheet -->
    <link rel="stylesheet" type="text/css" href="../includes/style.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Jquery cdn -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <!---------------------- Data Table links ------------------>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.12.1/datatables.min.css" />
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/autofill/2.4.0/css/autoFill.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">

    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.12.1/datatables.min.js"></script>
    <script type="text/javascript"
        src="https://cdn.datatables.net/autofill/2.4.0/js/dataTables.autoFill.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800&display=swap" rel="stylesheet">
    
</head>

<body>
    <input type="checkbox" id="nav-toggle">
    <div class="sidebar">
        <div class="sidebar-brand">
            <h3><i class="fa-solid fa-earth-americas pt-1"></i><span class="ms-3">SEPL</span></h3>
        </div>
        <div class="sidebar-menu">
            <ul>
                <li>
                    <a href="../pages/dashboard.php" id="dashboard" class="menu-link">
                        <div class="icon-box">
                            <i class="fa-solid fa-house"></i>
                        </div>
                        <span>Dashboard</span>
                    </a>
                    <div class="sub-menu mt-3">
                        <a href="../pages/dashboard.php" class="link_name" id="dashboard"></i>Dashboard</a>
                    </div>
                </li>
                <li>
                    <a href="../pages/software_changes.php" id="swChange" class="menu-link">
                        <div class="icon-box">
                        <i class="fa-solid fa-code"></i>
                        </div>
                        <span>Software Changes</span>
                    </a>
                    <div class="sub-menu">
                        <a href="../pages/software_changes.php" class="link_name" id="swChange">Software Changes</a>
                    </div>
                </li>
                <li>
                    <a href="../pages/link_2.php" id="link2" class="menu-link">
                        <div class="icon-box">
                            <i class="fa-solid fa-drum-steelpan "></i>
                        </div>
                        <span>New Link</span>
                    </a>
                    <div class="sub-menu">
                        <a href="../pages/link_2.php" class="link_name" id="link2">New Link</a>
                    </div>
                </li>
                <li class="submenuuu">
                    <a class="sub-btn drop-menu" href="#" id="Dmaster">
                        <div class="icon-box">
                            <i class="fa-solid fa-database"></i>
                        </div>
                        <span class="link_name">Link 2</span>
                        <i class="fas fa-angle-right dropdown"></i>
                    </a>
                    <div class="sub-menu">
                        <a href="#" class="link_name">Link 2</a>
                        <a href="../pages/sub_link_1.php" class="sub-item" id="subLink21">0. &nbsp;Sub Link 1</a>
                        <!-- <a href="name.php" class="sub-item">1. &nbsp; Name</a> -->
                        <a href="../pages/sub_link_2.php" class="sub-item" id="subLink22">1. &nbsp;Sub Link 2</a>
                    </div>
                </li>
                <!-- <li>
                    <a class="sub-btn drop-menu" href="#" id="Emaster">
                        <div class="icon-box">
                            <i class="fa-solid fa-database"></i>
                        </div>
                        <span>Link 3</span>
                        <i class="fas fa-angle-right dropdown"></i>
                    </a>
                    <div class="sub-menu">
                        <a href="#" class="link_name">Link 3</a>
                        <a href="#" class="sub-item" id="subLink31">0. &nbsp; Sub Link 1 </a>
                        <a href="#" class="sub-item" id="subLink32">1. &nbsp; Sub Link 2</a>
                        <a href="#" class="sub-item" id="subLink33">2. &nbsp; Sub Link 3</a>
                    </div>
                </li> -->
            </ul>
        </div>
    </div>
    <div class="main-content">
        <header>
            <div class="header-title">
                <label for="nav-toggle">
                    <i class="fa-solid fa-bars"></i>
                </label>
                <!-- <span>Dashboard</sapn> -->
            </div>
            <div class="user-wrapper d-flex align-items-center">
                <div class="profile">
                    <div class="info d-flex align-items-center">
                        <p>Hey, &nbsp;
                        <h4 data-bs-toggle="tooltip" data-bs-placement="bottom" title="Logout" id="logout_session" class="username">
                            <?php echo $_SESSION['name']; ?>
                        </h4>&nbsp;</p>
                        <!-- <small class="text-muted">Admin</small> -->
                    </div>
                </div>
                <script>
                    $(document).on("click", "#logout_session", function () {
                        if (confirm("Are you sure to Logout?!!")) {
                            window.open('./includes/logout.php', '_self');
                        }
                    });
                </script>
            </div>
        </header>
</body>

</html>